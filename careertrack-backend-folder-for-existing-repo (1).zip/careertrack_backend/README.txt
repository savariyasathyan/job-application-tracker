CareerTrack backend folder for the existing job-application-tracker repository.

Upload the folder named backend into the ROOT of your existing GitHub repository.
Do NOT upload your real .env file or database password.

Render settings after the folder is committed:
Root Directory: backend
Build Command: npm install
Start Command: npm start

Then add Environment Variables in Render:
MONGODB_URI = your real MongoDB Atlas connection string (keep private)

Important: The frontend still needs its API base URL updated to the Render service URL after deployment. Do not deploy until this backend folder is committed.
